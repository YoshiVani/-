#include <stdio.h>
#include <stdlib.h>

int main(void){
	int nx,ky;
	puts("linear search");
	printf("Number of elements : ");
	scanf("%d",&nx);
	int *x=calloc(nx,sizeof(int));
	
	for(int i=0;i<nx;i++){
		printf("x[%d] : ",i);
	scanf("%d",&x[i]);
}	
	
	printf("Value to look for : ");
	scanf("%d",&ky);
	
	int idx=search(x,nx,ky);
	if(idx==-1)puts("Search fails");
else printf("%d is in x[%d].\n",ky,idx);
free(x);
return 0;
}